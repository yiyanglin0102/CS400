package application;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

public class Main extends Application {
	private static final int filterX = 930;
	private static final int filterY = 100;

	TableView<FoodItem> table;
	TableView<FoodItem> customerTable;
	private File file;
	private Desktop desktop = Desktop.getDesktop();
	FoodData<FoodItem> f;
	List<FoodItem> list;
	// two data
	private final ObservableList<FoodItem> data = FXCollections.observableArrayList();
	private final ObservableList<FoodItem> customerData = FXCollections.observableArrayList();

	////////////////
	
	@Override
	public void start(Stage stage) {
		try {
			f = new FoodData<FoodItem>();
			list = new ArrayList<>();
			/////// Menu //////////////////////////////////
			FileChooser fileChooser = new FileChooser();
			
			Button buttonLoad = new Button("Load File...");
			Button buttonSave = new Button("Save File...");
			fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Files", "*.csv","*.txt"));
			buttonLoad.setOnAction(e -> {
				file = fileChooser.showOpenDialog(stage);
//				System.out.println(file.getPath());	
				f.loadFoodItems(file.getPath());
				list = f.getAllFoodItems();
				updateFoodItems(data, list);
			});
			
			buttonSave.setOnAction(e -> {
				
				
			});
			
			
			HBox IObox = new HBox();
			Label space = new Label("                         ");
			IObox.setSpacing(100);
			IObox.getChildren().addAll(space, buttonLoad, buttonSave);
			
//			MenuBar menuBar = new MenuBar();
//			Menu menuImport = new Menu("Import File...");
//			
//			Menu menuExport = new Menu("Export File...");
//			menuImport.setOnShowing(e -> {
//				System.out.println(123456);
//			});
//			menuBar.getMenus().addAll(menuImport, menuExport);
			
			

////////////////////////////////////////////////////////				
			
			
			

			// test
//				for (int i = 0; i < list.size(); i++) {
//					System.out.println(list.get(i).getNutrients().get("fat"));
//				}
//				System.out.println(list.size());

			///////////////////////////////////
			updateFoodItems(data, list);

			//////////////////////
			HBox hb = new HBox();
			HBox hb2 = new HBox();
			HBox hb3 = new HBox();

			table = new TableView<>();
			customerTable = new TableView<>();

			Scene scene = new Scene(new Group());
			stage.setTitle("Food List");
			stage.setWidth(1300);
			stage.setHeight(1100);

			final Label label = new Label("Food List");
			label.setFont(new Font("Arial", 20));

			///// column /////////////////////////////////////////////////////////////

			TableColumn<FoodItem, String> id = new TableColumn<>("ID");
			id.setMinWidth(30);
			id.setCellValueFactory(new PropertyValueFactory<>("ID"));

			TableColumn<FoodItem, String> foodNameCol = new TableColumn<>("Food Name");
			foodNameCol.setMinWidth(10);
			foodNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

			TableColumn<FoodItem, String> caloriesCol = new TableColumn<>("Calories");
			caloriesCol.setMinWidth(10);
			caloriesCol.setCellValueFactory(new PropertyValueFactory<>("calories"));

			TableColumn<FoodItem, String> fatCol = new TableColumn<>("Fat");
			fatCol.setMinWidth(10);
			fatCol.setCellValueFactory(new PropertyValueFactory<>("fat"));

			TableColumn<FoodItem, String> carbCol = new TableColumn<>("Carb");
			carbCol.setMinWidth(10);
			carbCol.setCellValueFactory(new PropertyValueFactory<>("carb"));

			TableColumn<FoodItem, String> proteinCol = new TableColumn<>("Protein");
			proteinCol.setMinWidth(10);
			proteinCol.setCellValueFactory(new PropertyValueFactory<>("protein"));

			TableColumn<FoodItem, String> fiberCol = new TableColumn<>("Fiber");
			fiberCol.setMinWidth(10);
			fiberCol.setCellValueFactory(new PropertyValueFactory<>("fiber"));

			////////////////////////////////////////////////////////////////////////

			table.setItems(data);
			table.getColumns().addAll(id, foodNameCol, caloriesCol, fatCol, carbCol, proteinCol, fiberCol);

			final TextField addFoodName = new TextField();
			addFoodName.setPromptText("Name");
			addFoodName.setMaxWidth(foodNameCol.getPrefWidth());

			final TextField addCalories = new TextField();
			addCalories.setMaxWidth(caloriesCol.getPrefWidth());
			addCalories.setPromptText("Calories");

			final TextField addFat = new TextField();
			addFat.setPromptText("Fat");
			addFat.setMaxWidth(fatCol.getPrefWidth());

			final TextField addCarb = new TextField();
			addCarb.setPromptText("Carb");
			addCarb.setMaxWidth(carbCol.getPrefWidth());

			final TextField addProtein = new TextField();
			addProtein.setPromptText("Protein");
			addProtein.setMaxWidth(proteinCol.getPrefWidth());

			final TextField addFiber = new TextField();
			addFiber.setPromptText("Fiber");
			addFiber.setMaxWidth(fiberCol.getPrefWidth());

			final TextField addID = new TextField();
			addID.setPromptText("Food ID");
			addID.setMaxWidth(id.getPrefWidth());

			final Button addButton = new Button("Add to Food List");
			addButton.setOnAction((ActionEvent e) -> {

				data.add(new FoodItem(addID.getText(), addFoodName.getText(), addCalories.getText(), addFat.getText(),
						addCarb.getText(), addProtein.getText(), addFiber.getText()));
				f.addFoodItem(new FoodItem(addID.getText(), addFoodName.getText(), addCalories.getText(),
						addFat.getText(), addCarb.getText(), addProtein.getText(), addFiber.getText()));

				addID.clear();
				addFoodName.clear();
				addCalories.clear();
				addFat.clear();
				addCarb.clear();
				addProtein.clear();
				addFiber.clear();
			});

			// delete selected row

			final Button deleteButton = new Button("Delete from Food List");
			deleteButton.setOnAction((ActionEvent e) -> {
				ObservableList<FoodItem> foodItemSelected, allfoodItems;
				allfoodItems = table.getItems();
				foodItemSelected = table.getSelectionModel().getSelectedItems();
				foodItemSelected.forEach(allfoodItems::remove);
			});

			hb.getChildren().addAll(addID, addFoodName, addCalories, addFat, addCarb, addProtein, addFiber, addButton,
					deleteButton);
			hb.setSpacing(3);

//////////			customerTable	////////////////////////// customerTable /////////////////////////////// customerTable	

			/// test put data

			customerTable.setEditable(false);

			TableColumn<FoodItem, String> foodNameCol1 = new TableColumn<>("Food Name");
			foodNameCol1.setMinWidth(10);
			foodNameCol1.setCellValueFactory(new PropertyValueFactory<>("name"));

			TableColumn<FoodItem, String> caloriesCol1 = new TableColumn<>("Calories");
			caloriesCol1.setMinWidth(10);
			caloriesCol1.setCellValueFactory(new PropertyValueFactory<>("calories"));

			TableColumn<FoodItem, String> fatCol1 = new TableColumn<>("Fat");
			fatCol1.setMinWidth(10);
			fatCol1.setCellValueFactory(new PropertyValueFactory<>("fat"));

			TableColumn<FoodItem, String> carbCol1 = new TableColumn<>("Carb");
			carbCol1.setMinWidth(10);
			carbCol1.setCellValueFactory(new PropertyValueFactory<>("carb"));

			TableColumn<FoodItem, String> proteinCol1 = new TableColumn<>("Protein");
			proteinCol1.setMinWidth(10);
			proteinCol1.setCellValueFactory(new PropertyValueFactory<>("protein"));

			TableColumn<FoodItem, String> fiberCol1 = new TableColumn<>("Fiber");
			fiberCol1.setMinWidth(10);
			fiberCol1.setCellValueFactory(new PropertyValueFactory<>("fiber"));

			TableColumn<FoodItem, String> id1 = new TableColumn<>("ID");
			id1.setMinWidth(30);
			id1.setCellValueFactory(new PropertyValueFactory<>("ID"));

			customerTable.setItems(customerData);
			customerTable.getColumns().addAll(id1, foodNameCol1, caloriesCol1, fatCol1, carbCol1, proteinCol1,
					fiberCol1);

			final Button ACL1 = new Button("     Add to Customer List   ");

			ACL1.setOnAction((ActionEvent e) -> {

				ObservableList<FoodItem> selected;

				selected = table.getSelectionModel().getSelectedItems();

				customerData.add(new FoodItem(selected.get(0).getID(), selected.get(0).getName(),
						selected.get(0).getCalories(), selected.get(0).getFat(), selected.get(0).getCarb(),
						selected.get(0).getProtein(), selected.get(0).getFiber()));
			});

			final Button DCL2 = new Button("Delete from Customer List");
			DCL2.setOnAction((ActionEvent e) -> {
				ObservableList<FoodItem> foodItemSelected, allfoodItems;
				allfoodItems = customerTable.getItems();
				foodItemSelected = customerTable.getSelectionModel().getSelectedItems();
				foodItemSelected.forEach(allfoodItems::remove);
			});

			final Button RCL3 = new Button("     Reset Customer List     ");
			RCL3.setOnAction((ActionEvent e) -> {
				customerTable.getItems().clear();
			});

			final Button ACL4 = new Button("   Analyze Customer List   ");

			ACL4.setOnAction((ActionEvent e) -> {
				customerTable.getItems().clear();
			});

			///////////// Filter ////////////////////// Filter ////////////////////////////
			///////////// Filter

			final Label label2 = new Label("Customer List");

			label2.setFont(Font.font("Verdana", 20));
			final Label nameLabel = new Label("Name");
			nameLabel.setLayoutX(filterX - 30);
			nameLabel.setLayoutY(filterY);

			final TextField nameBox = new TextField();
			nameBox.setPromptText("name");
			nameBox.setMaxWidth(foodNameCol.getPrefWidth());
			nameBox.setLayoutX(filterX + 70);
			nameBox.setLayoutY(filterY - 5);

			final Label calLabel = new Label("Calories");
			calLabel.setLayoutX(filterX - 30);
			calLabel.setLayoutY(filterY + 30);

			final Label calLabel1 = new Label("~");
			calLabel1.setLayoutX(filterX + 155);
			calLabel1.setLayoutY(filterY + 30);

			final TextField mincal = new TextField();
			mincal.setPromptText("minimun");
			mincal.setMaxWidth(foodNameCol.getPrefWidth());
			mincal.setLayoutX(filterX + 70);
			mincal.setLayoutY(filterY + 25);

			final TextField maxcal = new TextField();
			maxcal.setPromptText("maximun");
			maxcal.setMaxWidth(foodNameCol.getPrefWidth());
			maxcal.setLayoutX(filterX + 170);
			maxcal.setLayoutY(filterY + 25);

			final Label proteinLabel = new Label("Protein");
			proteinLabel.setLayoutX(filterX - 30);
			proteinLabel.setLayoutY(filterY + 60);

			final Label proteinLabel1 = new Label("~");
			proteinLabel1.setLayoutX(filterX + 155);
			proteinLabel1.setLayoutY(filterY + 60);

			final TextField minprotein = new TextField();
			minprotein.setPromptText("minimun");
			minprotein.setMaxWidth(foodNameCol.getPrefWidth());
			minprotein.setLayoutX(filterX + 70);
			minprotein.setLayoutY(filterY + 55);

			final TextField maxprotein = new TextField();
			maxprotein.setPromptText("maximun");
			maxprotein.setMaxWidth(foodNameCol.getPrefWidth());
			maxprotein.setLayoutX(filterX + 170);
			maxprotein.setLayoutY(filterY + 55);

			final Label fiberLabel = new Label("Fiber");
			fiberLabel.setLayoutX(filterX - 30);
			fiberLabel.setLayoutY(filterY + 90);

			final Label fiberLabel1 = new Label("~");
			fiberLabel1.setLayoutX(filterX + 155);
			fiberLabel1.setLayoutY(filterY + 90);

			final TextField minfiber = new TextField();
			minfiber.setPromptText("minimun");
			minfiber.setMaxWidth(foodNameCol.getPrefWidth());
			minfiber.setLayoutX(filterX + 70);
			minfiber.setLayoutY(filterY + 85);

			final TextField maxfiber = new TextField();
			maxfiber.setPromptText("maximun");
			maxfiber.setMaxWidth(foodNameCol.getPrefWidth());
			maxfiber.setLayoutX(filterX + 170);
			maxfiber.setLayoutY(filterY + 85);

			final Label fatLabel = new Label("Fat");
			fatLabel.setLayoutX(filterX - 30);
			fatLabel.setLayoutY(filterY + 120);

			final Label fatLabel1 = new Label("~");
			fatLabel1.setLayoutX(filterX + 155);
			fatLabel1.setLayoutY(filterY + 120);

			final TextField minfat = new TextField();
			minfat.setPromptText("minimun");
			minfat.setMaxWidth(foodNameCol.getPrefWidth());
			minfat.setLayoutX(filterX + 70);
			minfat.setLayoutY(filterY + 115);

			final TextField maxfat = new TextField();
			maxfat.setPromptText("maximun");
			maxfat.setMaxWidth(foodNameCol.getPrefWidth());
			maxfat.setLayoutX(filterX + 170);
			maxfat.setLayoutY(filterY + 115);

			final Label carbsLabel = new Label("Carbohydrate");
			carbsLabel.setLayoutX(filterX - 30);
			carbsLabel.setLayoutY(filterY + 150);

			final Label carbsLabel1 = new Label("~");
			carbsLabel1.setLayoutX(filterX + 155);
			carbsLabel1.setLayoutY(filterY + 150);

			final TextField mincarbs = new TextField();
			mincarbs.setPromptText("minimun");
			mincarbs.setMaxWidth(foodNameCol.getPrefWidth());
			mincarbs.setLayoutX(filterX + 70);
			mincarbs.setLayoutY(filterY + 145);

			final TextField maxcarbs = new TextField();
			maxcarbs.setPromptText("maximun");
			maxcarbs.setMaxWidth(foodNameCol.getPrefWidth());
			maxcarbs.setLayoutX(filterX + 170);
			maxcarbs.setLayoutY(filterY + 145);

			// filter button functions
			// ////////////////////////////////////////////////////////

			Button b2 = new Button("Reset");
			Button b3 = new Button("Filter");

			b3.setOnAction((ActionEvent e) -> {
				table.getItems().clear();

				List<String> RulesList = new ArrayList<String>();
				List<FoodItem> filtered2List = new ArrayList<FoodItem>();

				filtered2List = list;

				if (!nameBox.getText().trim().isEmpty()) {
					String substring = nameBox.getText();
					filtered2List = f.filterByName(substring);

				} else if (!mincal.getText().trim().isEmpty()) {
					List<FoodItem> filtered1List = new ArrayList<FoodItem>();
					String minimumCalRule = mincal.getText();
					String addedRule = "calories >= " + minimumCalRule;
					RulesList.add(addedRule);
					filtered1List = f.filterByNutrients(RulesList);
					filtered2List.retainAll(filtered1List);
				}

				updateFoodItems(data, filtered2List);

			});

			b2.setOnAction((ActionEvent e) -> {
				table.getItems().clear();
				nameBox.clear();
				mincal.clear();
				maxcal.clear();
				minprotein.clear();
				maxprotein.clear();
				minfiber.clear();
				maxfiber.clear();
				minfat.clear();
				maxfat.clear();
				mincarbs.clear();
				maxcarbs.clear();
				updateFoodItems(data, list);
			});

///////////// rules text boxes /////////////////////////// //
//				
//				table.getItems().clear();
//				
//				updateFoodItems(filteredList);
//				
//				if(!nameBox.getText().trim().isEmpty()) {
//					String substring = nameBox.getText();
//					List<FoodItem> filteredList = f.filterByName(substring);
//					table.getItems().clear();
//					updateFoodItems(filteredList);
//				}
//				
//				if(!mincal.getText().trim().isEmpty()) {
//					String minimumCalRule = mincal.getText();
//					String addedRule = "calories >= "+ minimumCalRule;
//					RulesList.add(addedRule);
//				}
//				
//				if(!maxcal.getText().trim().isEmpty()) {
//					String maximumCalRule = maxcal.getText();
//					String addedRule = "calories <= "+ maximumCalRule;
//					RulesList.add(addedRule);
//				}
//				
//				if(!minprotein.getText().trim().isEmpty()) {
//					String minimumProteinRule = minprotein.getText();
//					String addedRule = "protein >= "+ minimumProteinRule;
//					RulesList.add(addedRule);
//				}
//				if(!maxprotein.getText().trim().isEmpty()) {
//					String maximumProteinRule = maxprotein.getText();
//					String addedRule = "protein <= "+ maximumProteinRule;
//					RulesList.add(addedRule);
//				}
//				//
//				if(!minfiber.getText().trim().isEmpty()) {
//					String minimumFiberRule = minfiber.getText();
//					String addedRule = "fiber >= "+ minimumFiberRule;
//					RulesList.add(addedRule);
//				}
//				
//				if(!maxfiber.getText().trim().isEmpty()) {
//					String maximumFiberRule = maxfiber.getText();
//					String addedRule = "calories <= "+ maximumFiberRule;
//					RulesList.add(addedRule);
//				}
//				
//				if(!minfat.getText().trim().isEmpty()) {
//					String minimumFatRule = minfat.getText();
//					String addedRule = "protein >= "+ minimumFatRule;
//					RulesList.add(addedRule);
//				}
//				if(!maxfat.getText().trim().isEmpty()) {
//					String maximumFatRule = maxprotein.getText();
//					String addedRule = "protein <= "+ maximumFatRule;
//					RulesList.add(addedRule);
//				}
//				
//				if(!mincarbs.getText().trim().isEmpty()) {
//					String minimumCarbsRule = mincarbs.getText();
//					String addedRule = "protein >= "+ minimumCarbsRule;
//					RulesList.add(addedRule);
//				}
//				if(!maxcarbs.getText().trim().isEmpty()) {
//					String maximumCarbsRule = maxcarbs.getText();
//					String addedRule = "protein <= "+ maximumCarbsRule;
//					RulesList.add(addedRule);
//				}
//				
			/////////////////////////////////////////////
			hb2.getChildren().addAll(b2, b3);
			hb2.setSpacing(10);
			hb2.setLayoutX(filterX + 100);
			hb2.setLayoutY(filterY + 200);

			///////////// Filter ////////////////////// Filter ////////////////////////////
			///////////// Filter

			VBox vb3 = new VBox();
			vb3.setSpacing(10);
			vb3.setLayoutX(filterX);
			vb3.setLayoutY(filterY + 450);
			vb3.getChildren().addAll(ACL1, DCL2, RCL3, ACL4);

			final VBox vbox = new VBox();
//			final Label space = new Label("");
			vbox.setSpacing(5);
			vbox.setPadding(new Insets(10, 0, 0, 10));
			vbox.getChildren().addAll(IObox, label, table, hb, label2, customerTable);

			((Group) scene.getRoot()).getChildren().addAll(vb3, vbox, nameLabel, nameBox, mincal, maxcal, calLabel,
					calLabel1, minprotein, maxprotein, proteinLabel, proteinLabel1, minfiber, maxfiber, fiberLabel,
					fiberLabel1, minfat, maxfat, fatLabel, fatLabel1, mincarbs, maxcarbs, carbsLabel, carbsLabel1, hb2);

			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			stage.setScene(scene);
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void updateFoodItems(ObservableList<FoodItem> data, List<FoodItem> list) {
		for (int i = 0; i < list.size(); i++) {
			data.add(new FoodItem(list.get(i).getID(), list.get(i).getName(), list.get(i).getCalories(),
					list.get(i).getFat(), list.get(i).getCarb(), list.get(i).getProtein(), list.get(i).getFiber()));
		}

	}

	public static void main(String[] args) {
		launch(args);
	}
}
