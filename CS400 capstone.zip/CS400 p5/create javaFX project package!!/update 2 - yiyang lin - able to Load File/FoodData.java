package application;
import java.io.*;
import java.util.*;
import java.lang.*;

public class FoodData<F> implements FoodDataADT {

	private List<FoodItem> list;
//	private BPTree<String, Double> t;
	private List<String> ascendingList;

	FoodData() {
		list = new ArrayList<FoodItem>();
//		t = new BPTree<String, Double>(3);
	}

	@Override
	public void loadFoodItems(String filePath) {
		String[] details = new String[7];
		Scanner input;
		File file = new File(filePath);  
		try {
			input = new Scanner(file);

			while (input.hasNext()) {
				String line = input.nextLine();
				String[] read = line.split(",");
				details[0] = read[0];
				details[1] = read[1];
				details[2] = read[3];
				details[3] = read[5];
				details[4] = read[7];
				details[5] = read[9];
				details[6] = read[11];

				FoodItem food = new FoodItem(read[0], read[1], read[3], read[5], read[7], read[9], read[11]);

				food.addNutrient(read[2], Double.parseDouble(read[3]));
				food.addNutrient(read[4], Double.parseDouble(read[5]));
				food.addNutrient(read[6], Double.parseDouble(read[7]));
				food.addNutrient(read[8], Double.parseDouble(read[9]));
				food.addNutrient(read[10], Double.parseDouble(read[11]));

				list.add(food);

//				for (int j = 0; j < 7; j++) {
//					System.out.print(details[j] + ", ");
//				}
//				System.out.println();
			}
		} catch (Exception e) {
		}

	}

	@Override
	public List<F> filterByName(String substring) {

		List<FoodItem> filterList = new ArrayList<FoodItem>();

		for (int i = 0; i < list.size(); i++) {
			boolean bool = list.get(i).getName().toLowerCase().contains(substring.toLowerCase());
			if (bool) {
				filterList.add(list.get(i));
			}
		}
		return (List<F>) filterList;
	}

	@Override
	public List<F> filterByNutrients(List rules) {

		/////// have not finished only first rule can be applied

		List<FoodItem> List = list;
		List<FoodItem> changingList = new ArrayList<FoodItem>();
		String[] rule = new String[rules.size()];

		//////// split the rule string //////////// first rule
		String[] splited = ((String) rules.get(0)).split("\\s+");

		String factor = splited[0];
		double comparedNumber = Double.parseDouble(splited[2]);

		String operator = splited[1];

		//////////////////////////////////////////////

		for (int j = 0; j < List.size(); j++) {

			if (operator.equals("<=")) {
				double foodstat = List.get(j).getNutrientValue(factor);
				if (foodstat <= comparedNumber) {
					changingList.add (List.get(j));
				}

			}

			if (operator.equals("==")) {
				double foodstat = List.get(j).getNutrientValue(factor);
				if (foodstat == comparedNumber) {
					changingList.add (List.get(j));
				}
			}

			if (operator.equals(">=")) {
				double foodstat = List.get(j).getNutrientValue(factor);
				if (foodstat >= comparedNumber) {
					changingList.add (List.get(j));
				}
			}
		}

		return (List<F>)  changingList;
	}

	@Override
	public void addFoodItem(FoodItem foodItem) {
		list.add(foodItem);
		Collections.sort(list);
	}

	@Override
	public List<F> getAllFoodItems() {

//		List<FoodItem> allNameList = new ArrayList<FoodItem>();
//		for(int i=0; i< list.size(); i++)
//		{
//			allNameList.add(list.get(i));
//		}
		Collections.sort(list);
		return (List<F>) list;
	}

	@Override
	public void saveFoodItems(String filename) {

		
	}

}
