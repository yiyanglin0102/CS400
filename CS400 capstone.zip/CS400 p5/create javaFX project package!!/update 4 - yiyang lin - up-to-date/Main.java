package application;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

public class Main extends Application {
	private static final int filterX = 930;
	private static final int filterY = 100;

	private File file;
	private Desktop desktop = Desktop.getDesktop();
	FoodData<FoodItem> fooddata;
	List<FoodItem> list;
	List<FoodItem> customerlist;

	// two data
	private final ObservableList<FoodItem> data = FXCollections.observableArrayList();
	private final ObservableList<FoodItem> customerData = FXCollections.observableArrayList();
	private final ObservableList<FoodItem> backUpdata = FXCollections.observableArrayList();
	// two table
	private TableView<FoodItem> table;
	private TableView<FoodItem> customerTable;

	////////////////

	@Override
	public void start(Stage stage) {
		try {

			table = new TableView<>();
			customerTable = new TableView<>();
			list = new ArrayList<>();
			customerlist = new ArrayList<>();

			fooddata = new FoodData<FoodItem>();

			/////// Menu //////////////////////////////////
			FileChooser fileChooser = new FileChooser();

			Button buttonLoad = new Button("Load File...");
			Button buttonSave = new Button("Save File...");
			fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Files", "*.csv", "*.txt"));
			buttonLoad.setOnAction(e -> {
				file = fileChooser.showOpenDialog(stage);
				fooddata.loadFoodItems(file.getPath());
				list = fooddata.getAllFoodItems();
				updateFoodItems(data, list);
				updateFoodItems(backUpdata, list);
			});

			buttonSave.setOnAction(e -> {

				for (FoodItem eachItem : customerData) {
					customerlist.add(eachItem);
				}

				// test
//				for(int i =0; i < customerData.size(); i++)
//				{
//					System.out.println(customerData.get(i).getName());
//				}

				fooddata.setCustomerList(customerlist);
				fooddata.saveFoodItems("Created_Customer_Food_List.csv");
			});

			HBox IObox = new HBox();
			Label space = new Label("                         ");
			IObox.setSpacing(100);
			IObox.getChildren().addAll(space, buttonLoad, buttonSave);

////////////////////////////////////////////////////////				

			// test
//				for (int i = 0; i < list.size(); i++) {
//					System.out.println(list.get(i).getNutrients().get("fat"));
//				}
//				System.out.println(list.size());

			///////////////////////////////////
			

			///////////////////////////////////
			HBox hb = new HBox();
			HBox hb2 = new HBox();
			HBox hb3 = new HBox();

			Scene scene = new Scene(new Group());
			stage.setTitle("Food List");
			stage.setWidth(1300);
			stage.setHeight(1100);

			final Label label = new Label("Food List");
			label.setFont(new Font("Arial", 20));

			///// column /////////////////////////////////////////////////////////////

			TableColumn<FoodItem, String> id = new TableColumn<>("ID");
			id.setMinWidth(30);
			id.setCellValueFactory(new PropertyValueFactory<>("ID"));

			TableColumn<FoodItem, String> foodNameCol = new TableColumn<>("Food Name");
			foodNameCol.setMinWidth(10);
			foodNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

			TableColumn<FoodItem, String> caloriesCol = new TableColumn<>("Calories");
			caloriesCol.setMinWidth(10);
			caloriesCol.setCellValueFactory(new PropertyValueFactory<>("calories"));

			TableColumn<FoodItem, String> fatCol = new TableColumn<>("Fat");
			fatCol.setMinWidth(10);
			fatCol.setCellValueFactory(new PropertyValueFactory<>("fat"));

			TableColumn<FoodItem, String> carbCol = new TableColumn<>("Carb");
			carbCol.setMinWidth(10);
			carbCol.setCellValueFactory(new PropertyValueFactory<>("carb"));

			TableColumn<FoodItem, String> proteinCol = new TableColumn<>("Protein");
			proteinCol.setMinWidth(10);
			proteinCol.setCellValueFactory(new PropertyValueFactory<>("protein"));

			TableColumn<FoodItem, String> fiberCol = new TableColumn<>("Fiber");
			fiberCol.setMinWidth(10);
			fiberCol.setCellValueFactory(new PropertyValueFactory<>("fiber"));

			////////////////////////////////////////////////////////////////////////

			table.setItems(data);
			table.getColumns().addAll(id, foodNameCol, caloriesCol, fatCol, carbCol, proteinCol, fiberCol);

			final TextField addFoodName = new TextField();
			addFoodName.setPromptText("Name");
			addFoodName.setMaxWidth(foodNameCol.getPrefWidth());

			final TextField addCalories = new TextField();
			addCalories.setMaxWidth(caloriesCol.getPrefWidth());
			addCalories.setPromptText("Calories");

			final TextField addFat = new TextField();
			addFat.setPromptText("Fat");
			addFat.setMaxWidth(fatCol.getPrefWidth());

			final TextField addCarb = new TextField();
			addCarb.setPromptText("Carb");
			addCarb.setMaxWidth(carbCol.getPrefWidth());

			final TextField addProtein = new TextField();
			addProtein.setPromptText("Protein");
			addProtein.setMaxWidth(proteinCol.getPrefWidth());

			final TextField addFiber = new TextField();
			addFiber.setPromptText("Fiber");
			addFiber.setMaxWidth(fiberCol.getPrefWidth());

			final TextField addID = new TextField();
			addID.setPromptText("Food ID");
			addID.setMaxWidth(id.getPrefWidth());

			final Button addButton = new Button("Add to Food List");
			addButton.setOnAction((ActionEvent e) -> {

				data.add(new FoodItem(addID.getText(), addFoodName.getText(), addCalories.getText(), addFat.getText(),
						addCarb.getText(), addProtein.getText(), addFiber.getText()));
				fooddata.addFoodItem(new FoodItem(addID.getText(), addFoodName.getText(), addCalories.getText(),
						addFat.getText(), addCarb.getText(), addProtein.getText(), addFiber.getText()));

				addID.clear();
				addFoodName.clear();
				addCalories.clear();
				addFat.clear();
				addCarb.clear();
				addProtein.clear();
				addFiber.clear();
			});

			// delete selected row

			final Button deleteButton = new Button("Delete from Food List");
			deleteButton.setOnAction((ActionEvent e) -> {
				ObservableList<FoodItem> foodItemSelected, allfoodItems;
				allfoodItems = table.getItems();
				foodItemSelected = table.getSelectionModel().getSelectedItems();
				foodItemSelected.forEach(allfoodItems::remove);
			});

			hb.getChildren().addAll(addID, addFoodName, addCalories, addFat, addCarb, addProtein, addFiber, addButton,
					deleteButton);
			hb.setSpacing(3);

//////////			customerTable	////////////////////////// customerTable /////////////////////////////// customerTable	

			/// test put data

			customerTable.setEditable(false);

			TableColumn<FoodItem, String> foodNameCol1 = new TableColumn<>("Food Name");
			foodNameCol1.setMinWidth(10);
			foodNameCol1.setCellValueFactory(new PropertyValueFactory<>("name"));

			TableColumn<FoodItem, String> caloriesCol1 = new TableColumn<>("Calories");
			caloriesCol1.setMinWidth(10);
			caloriesCol1.setCellValueFactory(new PropertyValueFactory<>("calories"));

			TableColumn<FoodItem, String> fatCol1 = new TableColumn<>("Fat");
			fatCol1.setMinWidth(10);
			fatCol1.setCellValueFactory(new PropertyValueFactory<>("fat"));

			TableColumn<FoodItem, String> carbCol1 = new TableColumn<>("Carb");
			carbCol1.setMinWidth(10);
			carbCol1.setCellValueFactory(new PropertyValueFactory<>("carb"));

			TableColumn<FoodItem, String> proteinCol1 = new TableColumn<>("Protein");
			proteinCol1.setMinWidth(10);
			proteinCol1.setCellValueFactory(new PropertyValueFactory<>("protein"));

			TableColumn<FoodItem, String> fiberCol1 = new TableColumn<>("Fiber");
			fiberCol1.setMinWidth(10);
			fiberCol1.setCellValueFactory(new PropertyValueFactory<>("fiber"));

			TableColumn<FoodItem, String> id1 = new TableColumn<>("ID");
			id1.setMinWidth(30);
			id1.setCellValueFactory(new PropertyValueFactory<>("ID"));

			customerTable.setItems(customerData);
			customerTable.getColumns().addAll(id1, foodNameCol1, caloriesCol1, fatCol1, carbCol1, proteinCol1,
					fiberCol1);

			final Button ACL1 = new Button("     Add to Customer List   ");

			ACL1.setOnAction((ActionEvent e) -> {

				ObservableList<FoodItem> selected;

				selected = table.getSelectionModel().getSelectedItems();

				customerData.add(new FoodItem(selected.get(0).getID(), selected.get(0).getName(),
						selected.get(0).getCalories(), selected.get(0).getFat(), selected.get(0).getCarb(),
						selected.get(0).getProtein(), selected.get(0).getFiber()));
			});

			final Button DCL2 = new Button("Delete from Customer List");
			DCL2.setOnAction((ActionEvent e) -> {
				ObservableList<FoodItem> foodItemSelected, allfoodItems;
				allfoodItems = customerTable.getItems();
				foodItemSelected = customerTable.getSelectionModel().getSelectedItems();
				foodItemSelected.forEach(allfoodItems::remove);
			});

			final Button RCL3 = new Button("     Reset Customer List     ");
			RCL3.setOnAction((ActionEvent e) -> {
				customerTable.getItems().clear();
			});

			final Button ACL4 = new Button("   Analyze Customer List   ");

			ACL4.setOnAction((ActionEvent e) -> {
				customerTable.getItems().clear();
			});

			///////////// Filter ////////////////////// Filter ////////////////////////////
			///////////// Filter

			final Label label2 = new Label("Customer List");

			label2.setFont(Font.font("Verdana", 20));
			final Label nameLabel = new Label("Name");
			nameLabel.setLayoutX(filterX - 30);
			nameLabel.setLayoutY(filterY);

			final TextField nameBox = new TextField();
			nameBox.setPromptText("name");
			nameBox.setMaxWidth(foodNameCol.getPrefWidth());
			nameBox.setLayoutX(filterX + 70);
			nameBox.setLayoutY(filterY - 5);

			final Label calLabel = new Label("Calories");
			calLabel.setLayoutX(filterX - 30);
			calLabel.setLayoutY(filterY + 30);

			final Label calLabel1 = new Label("~");
			calLabel1.setLayoutX(filterX + 155);
			calLabel1.setLayoutY(filterY + 30);

			final TextField mincal = new TextField();
			mincal.setPromptText("minimun");
			mincal.setMaxWidth(foodNameCol.getPrefWidth());
			mincal.setLayoutX(filterX + 70);
			mincal.setLayoutY(filterY + 25);

			final TextField maxcal = new TextField();
			maxcal.setPromptText("maximun");
			maxcal.setMaxWidth(foodNameCol.getPrefWidth());
			maxcal.setLayoutX(filterX + 170);
			maxcal.setLayoutY(filterY + 25);

			final Label proteinLabel = new Label("Protein");
			proteinLabel.setLayoutX(filterX - 30);
			proteinLabel.setLayoutY(filterY + 60);

			final Label proteinLabel1 = new Label("~");
			proteinLabel1.setLayoutX(filterX + 155);
			proteinLabel1.setLayoutY(filterY + 60);

			final TextField minprotein = new TextField();
			minprotein.setPromptText("minimun");
			minprotein.setMaxWidth(foodNameCol.getPrefWidth());
			minprotein.setLayoutX(filterX + 70);
			minprotein.setLayoutY(filterY + 55);

			final TextField maxprotein = new TextField();
			maxprotein.setPromptText("maximun");
			maxprotein.setMaxWidth(foodNameCol.getPrefWidth());
			maxprotein.setLayoutX(filterX + 170);
			maxprotein.setLayoutY(filterY + 55);

			final Label fiberLabel = new Label("Fiber");
			fiberLabel.setLayoutX(filterX - 30);
			fiberLabel.setLayoutY(filterY + 90);

			final Label fiberLabel1 = new Label("~");
			fiberLabel1.setLayoutX(filterX + 155);
			fiberLabel1.setLayoutY(filterY + 90);

			final TextField minfiber = new TextField();
			minfiber.setPromptText("minimun");
			minfiber.setMaxWidth(foodNameCol.getPrefWidth());
			minfiber.setLayoutX(filterX + 70);
			minfiber.setLayoutY(filterY + 85);

			final TextField maxfiber = new TextField();
			maxfiber.setPromptText("maximun");
			maxfiber.setMaxWidth(foodNameCol.getPrefWidth());
			maxfiber.setLayoutX(filterX + 170);
			maxfiber.setLayoutY(filterY + 85);

			final Label fatLabel = new Label("Fat");
			fatLabel.setLayoutX(filterX - 30);
			fatLabel.setLayoutY(filterY + 120);

			final Label fatLabel1 = new Label("~");
			fatLabel1.setLayoutX(filterX + 155);
			fatLabel1.setLayoutY(filterY + 120);

			final TextField minfat = new TextField();
			minfat.setPromptText("minimun");
			minfat.setMaxWidth(foodNameCol.getPrefWidth());
			minfat.setLayoutX(filterX + 70);
			minfat.setLayoutY(filterY + 115);

			final TextField maxfat = new TextField();
			maxfat.setPromptText("maximun");
			maxfat.setMaxWidth(foodNameCol.getPrefWidth());
			maxfat.setLayoutX(filterX + 170);
			maxfat.setLayoutY(filterY + 115);

			final Label carbsLabel = new Label("Carbohydrate");
			carbsLabel.setLayoutX(filterX - 30);
			carbsLabel.setLayoutY(filterY + 150);

			final Label carbsLabel1 = new Label("~");
			carbsLabel1.setLayoutX(filterX + 155);
			carbsLabel1.setLayoutY(filterY + 150);

			final TextField mincarbs = new TextField();
			mincarbs.setPromptText("minimun");
			mincarbs.setMaxWidth(foodNameCol.getPrefWidth());
			mincarbs.setLayoutX(filterX + 70);
			mincarbs.setLayoutY(filterY + 145);

			final TextField maxcarbs = new TextField();
			maxcarbs.setPromptText("maximun");
			maxcarbs.setMaxWidth(foodNameCol.getPrefWidth());
			maxcarbs.setLayoutX(filterX + 170);
			maxcarbs.setLayoutY(filterY + 145);

			// filter button functions
			// ////////////////////////////////////////////////////////

			Button b2 = new Button("Reset");
			Button b3 = new Button("Filter");

			b3.setOnAction((ActionEvent e) -> {
				for(FoodItem item: backUpdata)
				{
					data.add(item);
				}
				table.getItems().clear();

				List<String> RulesList = new ArrayList<String>();
				List<FoodItem> filteredNameList = new ArrayList<FoodItem>();
				System.out.println(RulesList);
				
				

				if (!nameBox.getText().trim().isEmpty()) {
					String substring = nameBox.getText();
					filteredNameList = fooddata.filterByName(substring);
				} 
				
				
				if (!mincal.getText().trim().isEmpty()) {
					
					String numberOfRule = mincal.getText();
					String addedRule = "calories >= " + numberOfRule;
					RulesList.add(addedRule);
					System.out.println(RulesList);
					
					
				} if (!maxcal.getText().trim().isEmpty()) {
					
					String numberOfRule = maxcal.getText();
					String addedRule = "calories <= " + numberOfRule;
					RulesList.add(addedRule);
					System.out.println(RulesList);
					
					
				} if (!minprotein.getText().trim().isEmpty()) {
					
					String numberOfRule = minprotein.getText();
					String addedRule = "protein >= " + numberOfRule;
					RulesList.add(addedRule);
					System.out.println(RulesList);
					
					
				} if (!maxprotein.getText().trim().isEmpty()) {
					
					String numberOfRule = maxprotein.getText();
					String addedRule = "protein <= " + numberOfRule;
					RulesList.add(addedRule);
					System.out.println(RulesList);
					
					
				} if (!minfiber.getText().trim().isEmpty()) {
					
					String numberOfRule = minfiber.getText();
					String addedRule = "fiber >= " + numberOfRule;
					RulesList.add(addedRule);
					System.out.println(RulesList);
					
					
				}if (!maxfiber.getText().trim().isEmpty()) {
					
					String numberOfRule = maxfiber.getText();
					String addedRule = "fiber <= " + numberOfRule;
					RulesList.add(addedRule);
					System.out.println(RulesList);
					
					
				} if (!minfat.getText().trim().isEmpty()) {
					
					String numberOfRule = minfat.getText();
					String addedRule = "fat >= " + numberOfRule;
					RulesList.add(addedRule);
					System.out.println(RulesList);
					
					
				} if (!maxfat.getText().trim().isEmpty()) {
					
					String numberOfRule = maxfat.getText();
					String addedRule = "fat <= " + numberOfRule;
					RulesList.add(addedRule);
					System.out.println(RulesList);
					
					
				} if (!mincarbs.getText().trim().isEmpty()) {
					
					String numberOfRule = mincarbs.getText();
					String addedRule = "carbohydrate >= " + numberOfRule;
					RulesList.add(addedRule);
					System.out.println(RulesList);
					
					
				} else if (!maxcarbs.getText().trim().isEmpty()) {
					
					String numberOfRule = maxcarbs.getText();
					String addedRule = "carbohydrate <= " + numberOfRule;
					RulesList.add(addedRule);
					System.out.println(RulesList);
				}

				List<FoodItem> filterResult = new ArrayList<FoodItem>();

				if(!RulesList.isEmpty())
				{
					filterResult = fooddata.filterByNutrients(RulesList);
					filteredNameList.retainAll(filterResult);
					updateFoodItems(data, filteredNameList);
				}
				
				if(nameBox.getText().trim().isEmpty() && !RulesList.isEmpty())
				{
					updateFoodItems(data, filterResult);
				}
				if(RulesList.isEmpty() && !nameBox.getText().trim().isEmpty())
				{
					updateFoodItems(data, filteredNameList);
				}
				
			});

			b2.setOnAction((ActionEvent e) -> {
				table.getItems().clear();
				nameBox.clear();
				mincal.clear();
				maxcal.clear();
				minprotein.clear();
				maxprotein.clear();
				minfiber.clear();
				maxfiber.clear();
				minfat.clear();
				maxfat.clear();
				mincarbs.clear();
				maxcarbs.clear();
				
				for(FoodItem item: backUpdata)
				{
					data.add(item);
				}
				updateFoodItems(data, list);
			});

			/////////////////////////////////////////////
			hb2.getChildren().addAll(b2, b3);
			hb2.setSpacing(10);
			hb2.setLayoutX(filterX + 100);
			hb2.setLayoutY(filterY + 200);

			///////////// Filter ////////////////////// Filter ////////////////////////////
			///////////// Filter

			VBox vb3 = new VBox();
			vb3.setSpacing(10);
			vb3.setLayoutX(filterX);
			vb3.setLayoutY(filterY + 450);
			vb3.getChildren().addAll(ACL1, DCL2, RCL3, ACL4);

			final VBox vbox = new VBox();
//			final Label space = new Label("");
			vbox.setSpacing(5);
			vbox.setPadding(new Insets(10, 0, 0, 10));
			vbox.getChildren().addAll(IObox, label, table, hb, label2, customerTable);

			((Group) scene.getRoot()).getChildren().addAll(vb3, vbox, nameLabel, nameBox, mincal, maxcal, calLabel,
					calLabel1, minprotein, maxprotein, proteinLabel, proteinLabel1, minfiber, maxfiber, fiberLabel,
					fiberLabel1, minfat, maxfat, fatLabel, fatLabel1, mincarbs, maxcarbs, carbsLabel, carbsLabel1, hb2);

			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			stage.setScene(scene);
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void updateFoodItems(ObservableList<FoodItem> data, List<FoodItem> list1) {
		for (FoodItem list : list1) {
			data.add(new FoodItem(list.getID(), list.getName(), list.getCalories(), list.getFat(), list.getCarb(),
					list.getProtein(), list.getFiber()));
		}

	}

	public static void main(String[] args) {
		launch(args);
	}
}
