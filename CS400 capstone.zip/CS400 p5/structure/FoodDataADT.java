package application;

public interface FoodDataADT {

}
