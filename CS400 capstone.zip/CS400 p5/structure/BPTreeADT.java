package application;

public interface BPTreeADT {

}
