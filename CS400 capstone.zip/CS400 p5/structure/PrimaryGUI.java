package application;

public class PrimaryGUI {

}
