package application;

public class FoodItem {

}
