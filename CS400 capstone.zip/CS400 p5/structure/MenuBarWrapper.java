package application;

public class MenuBarWrapper {

}
