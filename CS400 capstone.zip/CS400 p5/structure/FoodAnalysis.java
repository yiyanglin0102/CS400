package application;

public class FoodAnalysis {

}
