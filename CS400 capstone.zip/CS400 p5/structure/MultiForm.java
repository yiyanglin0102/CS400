package application;

public class MultiForm {

}
