package application;

public class FoodData {

}
