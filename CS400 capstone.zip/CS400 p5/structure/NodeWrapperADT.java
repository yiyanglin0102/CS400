package application;

public interface NodeWrapperADT {

}
