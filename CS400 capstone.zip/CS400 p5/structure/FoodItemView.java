package application;

public class FoodItemView {

}
