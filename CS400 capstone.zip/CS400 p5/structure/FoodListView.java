package application;

public class FoodListView {

}
