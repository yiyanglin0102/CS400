package application;
	
//import java.awt.Button;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.*;


public class Main extends Application {
	 private ArrayList<PrimaryGUI> guiObjects = new ArrayList<PrimaryGUI>();
	//Button button;
	 @Override
	public void start(Stage primaryStage) {
		try {
			primaryStage.setTitle("Food Query and Meal Analyze");
			
			Button b1=new Button();
			b1.setText("Add Food");
			Button b2=new Button();
			b2.setText("Delete");
			Button b3=new Button();
			b3.setText("Analyze");
			Button b4=new Button();
			b4.setText("Filter Food List");
			Button b5=new Button();
			b5.setText("Selcet Food");
			Button b6=new Button();
			b6.setText("Reset");
//			button.setMaxWidth(100);
//			button.setMaxHeight(50);
//			button.setTranslateX(-440);
//			button.setTranslateY(-315);
			Label label1=new Label("");
			Region spacer = new Region();

			 
			VBox.setVgrow(spacer, Priority.ALWAYS);


			HBox hbox=new HBox(10,b1,b2,b3,b4,b5,b6);
			
			
			
			
			StackPane root = new StackPane();
			root.getChildren().add(hbox);
			
			Scene scene = new Scene(root,1000,700);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			
			
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
