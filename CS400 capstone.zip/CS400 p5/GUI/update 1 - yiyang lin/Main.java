import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
 
public class Main extends Application {
 
    private final TableView<FoodItem> table = new TableView<>();
    private final ObservableList<FoodItem> data =
            FXCollections.observableArrayList(
            new FoodItem("Stewarts_PremiumDarkChocolatewithMintCookieCrunch", "280", "51c38f5d97c3e6d3d972f08a"),
            new FoodItem("Yoplait_GreekYogurtLemon", "100", "556540ff5d613c9d5f5935a9"),
            new FoodItem("EssentialEveryday_BlendedStrawberryLowfatYogurt", "240", "55806622970e3b40405abbc7"),
            new FoodItem("Lancaster_SoftCremesButterscotchCaramel", "180", "528f56608c43e6311f002172"),
            new FoodItem("FromtheFields_PorridgeHeirloomRyeRosemaryWalnutRaisin", "140", "5568a873dab661451562e70f"));
    final HBox hb = new HBox();
 
    public static void main(String[] args) {
        launch(args);
    }
 
    @Override
    public void start(Stage stage) {
        Scene scene = new Scene(new Group());
        stage.setTitle("Table View Sample");
        stage.setWidth(1000);
        stage.setHeight(1000);
 
        final Label label = new Label("Food Table");
        label.setFont(new Font("Arial", 20));
 
        table.setEditable(true);
 
        TableColumn<FoodItem, String> foodNameCol = 
            new TableColumn<>("Food Name");
        foodNameCol.setMinWidth(400);
        foodNameCol.setCellValueFactory(
            new PropertyValueFactory<>("foodName"));
        
        foodNameCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
        foodNameCol.setOnEditCommit(
            (CellEditEvent<FoodItem, String> t) -> {
                ((FoodItem) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setFoodName(t.getNewValue());
        });
 
 
        TableColumn<FoodItem, String> nutrition = 
            new TableColumn<>("Nutrition");
        nutrition.setMinWidth(200);
        nutrition.setCellValueFactory(
            new PropertyValueFactory<>("nutrition"));
        nutrition.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
        nutrition.setOnEditCommit(
            (CellEditEvent<FoodItem, String> t) -> {
                ((FoodItem) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setNutrition(t.getNewValue());
        });
 
        TableColumn<FoodItem, String> id = new TableColumn<>("id");
        id.setMinWidth(300);
        id.setCellValueFactory(
            new PropertyValueFactory<>("ID"));
        id.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());       
        id.setOnEditCommit(
            (CellEditEvent<FoodItem, String> t) -> {
                ((FoodItem) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setID(t.getNewValue());
        });
 
        table.setItems(data);
        table.getColumns().addAll(foodNameCol, nutrition, id);
 
        final TextField addFoodName = new TextField();
        addFoodName.setPromptText("Food Name");
        addFoodName.setMaxWidth(foodNameCol.getPrefWidth());
        final TextField addNutrition = new TextField();
        addNutrition.setMaxWidth(nutrition.getPrefWidth());
        addNutrition.setPromptText("Nutrition");
        final TextField addID = new TextField();
        addID.setMaxWidth(id.getPrefWidth());
        addID.setPromptText("Food ID");
 
        final Button addButton = new Button("Add");
        addButton.setOnAction((ActionEvent e) -> {
            data.add(new FoodItem(
            		addFoodName.getText(),
            		addNutrition.getText(),
            		addID.getText()));
            addFoodName.clear();
            addNutrition.clear();
            addID.clear();
        });
 
        hb.getChildren().addAll(addFoodName, addNutrition, addID, addButton);
        hb.setSpacing(3);
 
        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(label, table, hb);
 
        ((Group) scene.getRoot()).getChildren().addAll(vbox);
 
        stage.setScene(scene);
        stage.show();
    }
 
    
}