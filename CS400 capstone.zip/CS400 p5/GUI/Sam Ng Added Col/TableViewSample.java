package application;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
 
public class TableViewSample extends Application {
 
    private final TableView<FoodItem> ta ble = new TableView<>();
    private final ObservableList<FoodItem> data =
            FXCollections.observableArrayList(
            new FoodItem("Id", "name", "cal", "fat", "carb", "protein", "fiber"));
//            new FoodItem("Yoplait_GreekYogurtLemon", "100", "556540ff5d613c9d5f5935a9"),
//            new FoodItem("EssentialEveryday_BlendedStrawberryLowfatYogurt", "240", "55806622970e3b40405abbc7"),
//            new FoodItem("Lancaster_SoftCremesButterscotchCaramel", "180", "528f56608c43e6311f002172"),
//            new FoodItem("FromtheFields_PorridgeHeirloomRyeRosemaryWalnutRaisin", "140", "5568a873dab661451562e70f"));
    final HBox hb = new HBox();
 
    public static void main(String[] args) {
        launch(args);
    }
 
    @Override
    public void start(Stage stage) {
        Scene scene = new Scene(new Group());
        stage.setTitle("Guy's Guide to Meals");
        stage.setWidth(1000);
        stage.setHeight(1000);
 
        final Label label = new Label("Food List");
        label.setFont(new Font("Arial", 20));
 
        table.setEditable(true);
 
        TableColumn<FoodItem, String> foodNameCol = 
            new TableColumn<>("Food Name");
        foodNameCol.setMinWidth(40);
        foodNameCol.setCellValueFactory(
            new PropertyValueFactory<>("foodName"));
        
        foodNameCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
        foodNameCol.setOnEditCommit(
            (CellEditEvent<FoodItem, String> t) -> {
                ((FoodItem) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setFoodName(t.getNewValue());
        });
 
 
        TableColumn<FoodItem, String> caloriesCol = 
            new TableColumn<>("Calories");
        caloriesCol.setMinWidth(20);
        caloriesCol.setCellValueFactory(
            new PropertyValueFactory<>("calories"));
        
        caloriesCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
        caloriesCol.setOnEditCommit(
            (CellEditEvent<FoodItem, String> t) -> {
                ((FoodItem) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setCalories(t.getNewValue());
        });
        
        TableColumn<FoodItem, String> fatCol = 
            new TableColumn<>("Fat");
        fatCol.setMinWidth(20);
        fatCol.setCellValueFactory(
            new PropertyValueFactory<>("fat"));
        
        fatCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
        fatCol.setOnEditCommit(
            (CellEditEvent<FoodItem, String> t) -> {
                ((FoodItem) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setFat(t.getNewValue());
        });
        
        TableColumn<FoodItem, String> carbCol = 
            new TableColumn<>("Carb");
        carbCol.setMinWidth(20);
        carbCol.setCellValueFactory(
            new PropertyValueFactory<>("carb"));
        
        carbCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
        carbCol.setOnEditCommit(
           (CellEditEvent<FoodItem, String> t) -> {
               ((FoodItem) t.getTableView().getItems().get(
                       t.getTablePosition().getRow())
                       ).setCarb(t.getNewValue());
        });
 
        
        TableColumn<FoodItem, String> proteinCol = 
            new TableColumn<>("Protein");
        proteinCol.setMinWidth(20);
        proteinCol.setCellValueFactory(
            new PropertyValueFactory<>("protein"));
        
        proteinCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
        proteinCol.setOnEditCommit(
            (CellEditEvent<FoodItem, String> t) -> {
                ((FoodItem) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setProtein(t.getNewValue());
        });
        
        TableColumn<FoodItem, String> fiberCol = 
            new TableColumn<>("Fiber");
        fiberCol.setMinWidth(20);
        fiberCol.setCellValueFactory(
            new PropertyValueFactory<>("fiber"));
        
        fiberCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
        fiberCol.setOnEditCommit(
            (CellEditEvent<FoodItem, String> t) -> {
                ((FoodItem) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setFiber(t.getNewValue());
        });
     
        TableColumn<FoodItem, String> id = new TableColumn<>("id");
        id.setMinWidth(30);
        id.setCellValueFactory(
            new PropertyValueFactory<>("ID"));
        
        id.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());       
        id.setOnEditCommit(
            (CellEditEvent<FoodItem, String> t) -> {
                ((FoodItem) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setID(t.getNewValue());
        });
 
        table.setItems(data);
        table.getColumns().addAll(id, foodNameCol, caloriesCol, fatCol,
        		carbCol, proteinCol, fiberCol);
 
        final TextField addFoodName = new TextField();
        addFoodName.setPromptText("Name");
        addFoodName.setMaxWidth(foodNameCol.getPrefWidth());
        
        final TextField addCalories = new TextField();
        addCalories.setMaxWidth(caloriesCol.getPrefWidth());
        addCalories.setPromptText("Calories");
        
        final TextField addFat = new TextField();
        addFat.setPromptText("Fat");
        addFat.setMaxWidth(fatCol.getPrefWidth());
        
        final TextField addCarb = new TextField();
        addCarb.setPromptText("Carb");
        addCarb.setMaxWidth(carbCol.getPrefWidth());
        
        final TextField addProtein = new TextField();
        addProtein.setPromptText("Protein");
        addProtein.setMaxWidth(proteinCol.getPrefWidth());
        
        final TextField addFiber = new TextField();
        addFiber.setPromptText("Fiber");
        addFiber.setMaxWidth(fiberCol.getPrefWidth());
        
        final TextField addID = new TextField();
        addID.setPromptText("Food ID");
        addID.setMaxWidth(id.getPrefWidth());
 
        final Button addButton = new Button("Add");
        addButton.setOnAction((ActionEvent e) -> {
            data.add(new FoodItem(
            		addID.getText(),
            		addFoodName.getText(),
            		addCalories.getText(),
            		addFat.getText(),
            		addCarb.getText(),
            		addProtein.getText(),
            		addFiber.getText()));
            addID.clear();
            addFoodName.clear();
            addCalories.clear();
            addFat.clear();
            addCarb.clear();
            addProtein.clear();
            addFiber.clear();
        });
 
        hb.getChildren().addAll(addID, addFoodName, addCalories, addFat,
        		addCarb, addProtein, addFiber, addButton);
        hb.setSpacing(3);
 
        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(label, table, hb);
 
        ((Group) scene.getRoot()).getChildren().addAll(vbox);
 
        stage.setScene(scene);
        stage.show();
    }
 
    public static class FoodItem {
 
        private final SimpleStringProperty foodName;
        private final SimpleStringProperty calories;
        private final SimpleStringProperty fat;
        private final SimpleStringProperty carb;
        private final SimpleStringProperty protein;
        private final SimpleStringProperty fiber;
        private final SimpleStringProperty id;
        
 
        private FoodItem(String id, String foodName, String calories,
        		String fat, String carb, String protein, String fiber) {
            this.foodName = new SimpleStringProperty(foodName);
            this.calories = new SimpleStringProperty(calories);
            this.fat = new SimpleStringProperty(fat);
            this.carb = new SimpleStringProperty(carb);
            this.protein = new SimpleStringProperty(protein);
            this.fiber = new SimpleStringProperty(fiber);
            this.id = new SimpleStringProperty(id);
        }
 
        public String getFoodName() {
            return foodName.get();
        }
 
        public void setFoodName(String name) {
        	foodName.set(name);
        }
 
        public String getCalories() {
            return calories.get();
        }
 
        public void setCalories(String cal) {
        	calories.set(cal);
        }
 
        public String getFat() {
            return fat.get();
        }
 
        public void setFat(String fat) {
        	this.fat.set(fat);
        }
        
        public String getCarb() {
            return carb.get();
        }
 
        public void setCarb(String carb) {
        	this.carb.set(carb);
        }
        
        public String getProtein() {
            return protein.get();
        }
 
        public void setProtein(String protein) {
        	this.protein.set(protein);
        }
        
        public String getFiber() {
            return fiber.get();
        }
 
        public void setFiber(String fiber) {
        	this.fiber.set(fiber);
        }
        
        public String getID() {
            return id.get();
        }
 
        public void setID(String fName) {
        	id.set(fName);
        }
    }
}