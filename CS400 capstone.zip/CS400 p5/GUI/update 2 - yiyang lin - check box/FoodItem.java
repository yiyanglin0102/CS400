import javafx.beans.property.SimpleStringProperty;

public class FoodItem {

	private final SimpleStringProperty foodName;
	private final SimpleStringProperty nutrition;
	private final SimpleStringProperty id;

	FoodItem(String fName, String lName, String id) {
		this.foodName = new SimpleStringProperty(fName);
		this.nutrition = new SimpleStringProperty(lName);
		this.id = new SimpleStringProperty(id);
	}

	public String getFoodName() {
		return foodName.get();
	}

	public void setFoodName(String fName) {
		foodName.set(fName);
	}

	public String getNutrition() {
		return nutrition.get();
	}

	public void setNutrition(String fName) {
		nutrition.set(fName);
	}

	public String getID() {
		return id.get();
	}

	public void setID(String fName) {
		id.set(fName);
	}
}