import javafx.beans.property.SimpleStringProperty;

public class FoodItem {

	private final SimpleStringProperty foodName;
	private final SimpleStringProperty calories;
	private final SimpleStringProperty fat;
	private final SimpleStringProperty carb;
	private final SimpleStringProperty protein;
	private final SimpleStringProperty fiber;
	private final SimpleStringProperty id;

	FoodItem(String id, String foodName, String calories, String fat, String carb, String protein,
			String fiber) {
		this.foodName = new SimpleStringProperty(foodName);
		this.calories = new SimpleStringProperty(calories);
		this.fat = new SimpleStringProperty(fat);
		this.carb = new SimpleStringProperty(carb);
		this.protein = new SimpleStringProperty(protein);
		this.fiber = new SimpleStringProperty(fiber);
		this.id = new SimpleStringProperty(id);
	}

	public String getFoodName() {
		return foodName.get();
	}

	public void setFoodName(String name) {
		foodName.set(name);
	}

	public String getCalories() {
		return calories.get();
	}

	public void setCalories(String cal) {
		calories.set(cal);
	}

	public String getFat() {
		return fat.get();
	}

	public void setFat(String fat) {
		this.fat.set(fat);
	}

	public String getCarb() {
		return carb.get();
	}

	public void setCarb(String carb) {
		this.carb.set(carb);
	}

	public String getProtein() {
		return protein.get();
	}

	public void setProtein(String protein) {
		this.protein.set(protein);
	}

	public String getFiber() {
		return fiber.get();
	}

	public void setFiber(String fiber) {
		this.fiber.set(fiber);
	}

	public String getID() {
		return id.get();
	}

	public void setID(String fName) {
		id.set(fName);
	}
}
