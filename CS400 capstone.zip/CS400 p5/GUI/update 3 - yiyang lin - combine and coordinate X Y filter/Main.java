import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Main extends Application {
	private static final int filterX = 680;
	private static final int filterY = 100;
	private final TableView<FoodItem> table = new TableView<>();
	private final ObservableList<FoodItem> data = FXCollections.observableArrayList(
			new FoodItem("Id", "name", "cal", "fat", "carb", "protein", "fiber"),
			new FoodItem("51c38f5d97c3e6d3d972f08a", "Similac_FormulaSoyforDiarrheaReadytoFeed", "100", "0", "0", "0",
					"3"),
			new FoodItem("556540ff5d613c9d5f5935a9", "Yoplait_GreekYogurtLemon", "100", "0", "14", "0", "10"),
			new FoodItem("55806622970e3b40405abbc7", "Stewarts_PremiumDarkChocolatewithMintCookieCrunch", "280", "18",
					"34", "3", "3"),
			new FoodItem("Id", "name", "cal", "fat", "carb", "protein", "fiber"),
			new FoodItem("51c38f5d97c3e6d3d972f08a", "Similac_FormulaSoyforDiarrheaReadytoFeed", "100", "0", "0", "0",
					"3"),
			new FoodItem("556540ff5d613c9d5f5935a9", "Yoplait_GreekYogurtLemon", "100", "0", "14", "0", "10"),
			new FoodItem("55806622970e3b40405abbc7", "Stewarts_PremiumDarkChocolatewithMintCookieCrunch", "280", "18",
					"34", "3", "3"),
			new FoodItem("Id", "name", "cal", "fat", "carb", "protein", "fiber"),
			new FoodItem("51c38f5d97c3e6d3d972f08a", "Similac_FormulaSoyforDiarrheaReadytoFeed", "100", "0", "0", "0",
					"3"),
			new FoodItem("556540ff5d613c9d5f5935a9", "Yoplait_GreekYogurtLemon", "100", "0", "14", "0", "10"),
			new FoodItem("55806622970e3b40405abbc7", "Stewarts_PremiumDarkChocolatewithMintCookieCrunch", "280", "18",
					"34", "3", "3"),
			new FoodItem("Id", "name", "cal", "fat", "carb", "protein", "fiber"),
			new FoodItem("51c38f5d97c3e6d3d972f08a", "Similac_FormulaSoyforDiarrheaReadytoFeed", "100", "0", "0", "0",
					"3"),
			new FoodItem("556540ff5d613c9d5f5935a9", "Yoplait_GreekYogurtLemon", "100", "0", "14", "0", "10"),
			new FoodItem("55806622970e3b40405abbc7", "Stewarts_PremiumDarkChocolatewithMintCookieCrunch", "280", "18",
					"34", "3", "3"),
			new FoodItem("Id", "name", "cal", "fat", "carb", "protein", "fiber"),
			new FoodItem("51c38f5d97c3e6d3d972f08a", "Similac_FormulaSoyforDiarrheaReadytoFeed", "100", "0", "0", "0",
					"3"),
			new FoodItem("556540ff5d613c9d5f5935a9", "Yoplait_GreekYogurtLemon", "100", "0", "14", "0", "10"),
			new FoodItem("55806622970e3b40405abbc7", "Stewarts_PremiumDarkChocolatewithMintCookieCrunch", "280", "18",
					"34", "3", "3"),
			new FoodItem("Id", "name", "cal", "fat", "carb", "protein", "fiber"),
			new FoodItem("51c38f5d97c3e6d3d972f08a", "Similac_FormulaSoyforDiarrheaReadytoFeed", "100", "0", "0", "0",
					"3"),
			new FoodItem("556540ff5d613c9d5f5935a9", "Yoplait_GreekYogurtLemon", "100", "0", "14", "0", "10"),
			new FoodItem("55806622970e3b40405abbc7", "Stewarts_PremiumDarkChocolatewithMintCookieCrunch", "280", "18",
					"34", "3", "3"),
			new FoodItem("5568a873dab661451562e70f", "FromtheFields_PorridgeHeirloomRyeRosemaryWalnutRaisin", "140",
					"2.5", "45", "0", "10"));

	final HBox hb = new HBox();

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) {
		Scene scene = new Scene(new Group());
		stage.setTitle("Food List");
		stage.setWidth(1100);
		stage.setHeight(550);

		final Label label = new Label("Food List");
		label.setFont(new Font("Arial", 20));

		table.setEditable(true);

		TableColumn<FoodItem, String> foodNameCol = new TableColumn<>("Food Name");
		foodNameCol.setMinWidth(10);
		foodNameCol.setCellValueFactory(new PropertyValueFactory<>("foodName"));

		foodNameCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
		foodNameCol.setOnEditCommit((CellEditEvent<FoodItem, String> t) -> {
			((FoodItem) t.getTableView().getItems().get(t.getTablePosition().getRow())).setFoodName(t.getNewValue());
		});

		TableColumn<FoodItem, String> caloriesCol = new TableColumn<>("Calories");
		caloriesCol.setMinWidth(10);
		caloriesCol.setCellValueFactory(new PropertyValueFactory<>("calories"));

		caloriesCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
		caloriesCol.setOnEditCommit((CellEditEvent<FoodItem, String> t) -> {
			((FoodItem) t.getTableView().getItems().get(t.getTablePosition().getRow())).setCalories(t.getNewValue());
		});

		TableColumn<FoodItem, String> fatCol = new TableColumn<>("Fat");
		fatCol.setMinWidth(10);
		fatCol.setCellValueFactory(new PropertyValueFactory<>("fat"));

		fatCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
		fatCol.setOnEditCommit((CellEditEvent<FoodItem, String> t) -> {
			((FoodItem) t.getTableView().getItems().get(t.getTablePosition().getRow())).setFat(t.getNewValue());
		});

		TableColumn<FoodItem, String> carbCol = new TableColumn<>("Carb");
		carbCol.setMinWidth(10);
		carbCol.setCellValueFactory(new PropertyValueFactory<>("carb"));

		carbCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
		carbCol.setOnEditCommit((CellEditEvent<FoodItem, String> t) -> {
			((FoodItem) t.getTableView().getItems().get(t.getTablePosition().getRow())).setCarb(t.getNewValue());
		});

		TableColumn<FoodItem, String> proteinCol = new TableColumn<>("Protein");
		proteinCol.setMinWidth(10);
		proteinCol.setCellValueFactory(new PropertyValueFactory<>("protein"));

		proteinCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
		proteinCol.setOnEditCommit((CellEditEvent<FoodItem, String> t) -> {
			((FoodItem) t.getTableView().getItems().get(t.getTablePosition().getRow())).setProtein(t.getNewValue());
		});

		TableColumn<FoodItem, String> fiberCol = new TableColumn<>("Fiber");
		fiberCol.setMinWidth(10);
		fiberCol.setCellValueFactory(new PropertyValueFactory<>("fiber"));

		fiberCol.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
		fiberCol.setOnEditCommit((CellEditEvent<FoodItem, String> t) -> {
			((FoodItem) t.getTableView().getItems().get(t.getTablePosition().getRow())).setFiber(t.getNewValue());
		});

		TableColumn<FoodItem, String> id = new TableColumn<>("ID");
		id.setMinWidth(30);
		id.setCellValueFactory(new PropertyValueFactory<>("ID"));

		id.setCellFactory(TextFieldTableCell.<FoodItem>forTableColumn());
		id.setOnEditCommit((CellEditEvent<FoodItem, String> t) -> {
			((FoodItem) t.getTableView().getItems().get(t.getTablePosition().getRow())).setID(t.getNewValue());
		});

		table.setItems(data);
		table.getColumns().addAll(id, foodNameCol, caloriesCol, fatCol, carbCol, proteinCol, fiberCol);

		final TextField addFoodName = new TextField();
		addFoodName.setPromptText("Name");
		addFoodName.setMaxWidth(foodNameCol.getPrefWidth());

		final TextField addCalories = new TextField();
		addCalories.setMaxWidth(caloriesCol.getPrefWidth());
		addCalories.setPromptText("Calories");

		final TextField addFat = new TextField();
		addFat.setPromptText("Fat");
		addFat.setMaxWidth(fatCol.getPrefWidth());

		final TextField addCarb = new TextField();
		addCarb.setPromptText("Carb");
		addCarb.setMaxWidth(carbCol.getPrefWidth());

		final TextField addProtein = new TextField();
		addProtein.setPromptText("Protein");
		addProtein.setMaxWidth(proteinCol.getPrefWidth());

		final TextField addFiber = new TextField();
		addFiber.setPromptText("Fiber");
		addFiber.setMaxWidth(fiberCol.getPrefWidth());

		final TextField addID = new TextField();
		addID.setPromptText("Food ID");
		addID.setMaxWidth(id.getPrefWidth());

		final Button addButton = new Button("Add");
		addButton.setOnAction((ActionEvent e) -> {
			data.add(new FoodItem(addID.getText(), addFoodName.getText(), addCalories.getText(), addFat.getText(),
					addCarb.getText(), addProtein.getText(), addFiber.getText()));
			addID.clear();
			addFoodName.clear();
			addCalories.clear();
			addFat.clear();
			addCarb.clear();
			addProtein.clear();
			addFiber.clear();
		});

		hb.getChildren().addAll(addID, addFoodName, addCalories, addFat, addCarb, addProtein, addFiber, addButton);
		hb.setSpacing(3);
		final Label nameLabel = new Label("name");
		nameLabel.setLayoutX(filterX);
		nameLabel.setLayoutY(filterY);

		final TextField nameBox = new TextField();
		nameBox.setPromptText("name");
		nameBox.setMaxWidth(foodNameCol.getPrefWidth());
		nameBox.setLayoutX(filterX + 70);
		nameBox.setLayoutY(filterY - 5);

		final Label calLabel = new Label("calories");
		calLabel.setLayoutX(filterX);
		calLabel.setLayoutY(filterY + 30);

		final Label calLabel1 = new Label("~");
		calLabel1.setLayoutX(filterX + 155);
		calLabel1.setLayoutY(filterY + 30);

		final TextField mincal = new TextField();
		mincal.setPromptText("minimun");
		mincal.setMaxWidth(foodNameCol.getPrefWidth());
		mincal.setLayoutX(filterX + 70);
		mincal.setLayoutY(filterY + 25);

		final TextField maxcal = new TextField();
		maxcal.setPromptText("maximun");
		maxcal.setMaxWidth(foodNameCol.getPrefWidth());
		maxcal.setLayoutX(filterX + 170);
		maxcal.setLayoutY(filterY + 25);

		final Label proteinLabel = new Label("protein");
		proteinLabel.setLayoutX(filterX);
		proteinLabel.setLayoutY(filterY + 60);

		final Label proteinLabel1 = new Label("~");
		proteinLabel1.setLayoutX(filterX + 155);
		proteinLabel1.setLayoutY(filterY + 60);

		final TextField minprotein = new TextField();
		minprotein.setPromptText("minimun");
		minprotein.setMaxWidth(foodNameCol.getPrefWidth());
		minprotein.setLayoutX(filterX + 70);
		minprotein.setLayoutY(filterY + 55);

		final TextField maxprotein = new TextField();
		maxprotein.setPromptText("maximun");
		maxprotein.setMaxWidth(foodNameCol.getPrefWidth());
		maxprotein.setLayoutX(filterX + 170);
		maxprotein.setLayoutY(filterY + 55);

		final Label fiberLabel = new Label("fiber");
		fiberLabel.setLayoutX(filterX);
		fiberLabel.setLayoutY(filterY + 90);

		final Label fiberLabel1 = new Label("~");
		fiberLabel1.setLayoutX(filterX + 155);
		fiberLabel1.setLayoutY(filterY + 90);

		final TextField minfiber = new TextField();
		minfiber.setPromptText("minimun");
		minfiber.setMaxWidth(foodNameCol.getPrefWidth());
		minfiber.setLayoutX(filterX + 70);
		minfiber.setLayoutY(filterY + 85);

		final TextField maxfiber = new TextField();
		maxfiber.setPromptText("maximun");
		maxfiber.setMaxWidth(foodNameCol.getPrefWidth());
		maxfiber.setLayoutX(filterX + 170);
		maxfiber.setLayoutY(filterY + 85);

		final Label fatLabel = new Label("fat");
		fatLabel.setLayoutX(filterX);
		fatLabel.setLayoutY(filterY + 120);

		final Label fatLabel1 = new Label("~");
		fatLabel1.setLayoutX(filterX + 155);
		fatLabel1.setLayoutY(filterY + 120);

		final TextField minfat = new TextField();
		minfat.setPromptText("minimun");
		minfat.setMaxWidth(foodNameCol.getPrefWidth());
		minfat.setLayoutX(filterX + 70);
		minfat.setLayoutY(filterY + 115);

		final TextField maxfat = new TextField();
		maxfat.setPromptText("maximun");
		maxfat.setMaxWidth(foodNameCol.getPrefWidth());
		maxfat.setLayoutX(filterX + 170);
		maxfat.setLayoutY(filterY + 115);

		final Label carbsLabel = new Label("carbs");
		carbsLabel.setLayoutX(filterX);
		carbsLabel.setLayoutY(filterY + 150);

		final Label carbsLabel1 = new Label("~");
		carbsLabel1.setLayoutX(filterX + 155);
		carbsLabel1.setLayoutY(filterY + 150);

		final TextField mincarbs = new TextField();
		mincarbs.setPromptText("minimun");
		mincarbs.setMaxWidth(foodNameCol.getPrefWidth());
		mincarbs.setLayoutX(filterX + 70);
		mincarbs.setLayoutY(filterY + 145);

		final TextField maxcarbs = new TextField();
		maxcarbs.setPromptText("maximun");
		maxcarbs.setMaxWidth(foodNameCol.getPrefWidth());
		maxcarbs.setLayoutX(filterX + 170);
		maxcarbs.setLayoutY(filterY + 145);

		TableView<FoodItem> finalTable = new TableView<>();

		HBox hb2 = new HBox();

		Button b1 = new Button();
		b1.setText("Delete Food");

		Button b2 = new Button();
		b2.setText("Reset Selection");

		Button b3 = new Button();
		b3.setText("Filter");

		hb2.setSpacing(10);
		hb2.setLayoutX(filterX + 100);
		hb2.setLayoutY(filterY + 200);

		hb2.getChildren().addAll(b1, b2, b3);

		final VBox vbox = new VBox();
		vbox.setSpacing(20);
		vbox.setPadding(new Insets(10, 0, 0, 10));
		vbox.getChildren().addAll(label, hb2, table, hb, finalTable);
		((Group) scene.getRoot()).getChildren().addAll(vbox);
		((Group) scene.getRoot()).getChildren().addAll(nameLabel);
		((Group) scene.getRoot()).getChildren().addAll(nameBox);
		((Group) scene.getRoot()).getChildren().addAll(mincal);
		((Group) scene.getRoot()).getChildren().addAll(maxcal);
		((Group) scene.getRoot()).getChildren().addAll(calLabel);
		((Group) scene.getRoot()).getChildren().addAll(calLabel1);
		((Group) scene.getRoot()).getChildren().addAll(minprotein);
		((Group) scene.getRoot()).getChildren().addAll(maxprotein);
		((Group) scene.getRoot()).getChildren().addAll(proteinLabel);
		((Group) scene.getRoot()).getChildren().addAll(proteinLabel1);
		((Group) scene.getRoot()).getChildren().addAll(minfiber);
		((Group) scene.getRoot()).getChildren().addAll(maxfiber);
		((Group) scene.getRoot()).getChildren().addAll(fiberLabel);
		((Group) scene.getRoot()).getChildren().addAll(fiberLabel1);
		((Group) scene.getRoot()).getChildren().addAll(minfat);
		((Group) scene.getRoot()).getChildren().addAll(maxfat);
		((Group) scene.getRoot()).getChildren().addAll(fatLabel);
		((Group) scene.getRoot()).getChildren().addAll(fatLabel1);
		((Group) scene.getRoot()).getChildren().addAll(mincarbs);
		((Group) scene.getRoot()).getChildren().addAll(maxcarbs);
		((Group) scene.getRoot()).getChildren().addAll(carbsLabel);
		((Group) scene.getRoot()).getChildren().addAll(carbsLabel1);
		((Group) scene.getRoot()).getChildren().addAll(hb2);
		stage.setScene(scene);
		stage.show();
	}

}