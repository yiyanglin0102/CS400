import java.util.*;

import javafx.beans.property.SimpleStringProperty;

/**
 * This class represents a food item with all its properties.
 * 
 * @author aka
 */
public class FoodItem implements Comparable<FoodItem> {
	// The name of the food item.
	private String name;

	// The id of the food item.
	private String id;

	private String calories;
	private String fat;
	private String carb;
	private String protein;
	private String fiber;

	// Map of nutrients and value.
	private HashMap<String, Double> nutrients;

	/**
	 * Constructor
	 * 
	 * @param name name of the food item
	 * @param id   unique id of the food item
	 */
	public FoodItem(String id, String name) {
		this.name = name;
		this.id = id;
		nutrients = new HashMap<String, Double>();
	}

	public FoodItem(String id, String name, String calories, String fat, String carb, String protein, String fiber) {
		this.id = id;
		this.name = name;
		this.calories = calories;
		this.fat = fat;
		this.carb = carb;
		this.protein = protein;
		this.fiber = fiber;
		nutrients = new HashMap<String, Double>();
	}

	/**
	 * Gets the name of the food item
	 * 
	 * @return name of the food item
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the unique id of the food item
	 * 
	 * @return id of the food item
	 */
	public String getID() {
		return id;
	}

	/**
	 * Gets the nutrients of the food item
	 * 
	 * @return nutrients of the food item
	 */
	public HashMap<String, Double> getNutrients() {

		return nutrients;
	}

	/**
	 * Adds a nutrient and its value to this food. If nutrient already exists,
	 * updates its value.
	 */
	public void addNutrient(String name, double value) {
		nutrients.put(name, value);
	}

	/**
	 * Returns the value of the given nutrient for this food item. If not present,
	 * then returns 0.
	 */
	public double getNutrientValue(String name) {

		if (!nutrients.containsKey(name)) {
			return 0;
		}

		return nutrients.get(name);
	}

	public int compareTo(FoodItem a) {
		return this.getName().compareTo(a.getName());

	}

	public String getFat() {
		 return fat;
	}
	public String getCarb() {
		 return carb;
	}
	public String getCalories() {
				 return calories;
	}
	public String getProtein() {
		 return protein;
	}
	
	public String getFiber() {
		 return fiber;
	}

}
