import java.util.*;

public class test {

	public static void main(String[] args) {

//		HashMap<String, Double> nutrients  = new HashMap<String, Double>();
//		
//	
//		nutrients.put("e", 1.0);
//		nutrients.put("c", 3.);
//		nutrients.put("a", 5.0);
//		nutrients.put("b", 8.);

		
		
		FoodData<FoodItem> f = new FoodData<FoodItem>();
		
		
		// test of loadFoodItems()
		f.loadFoodItems("foodItems.csv");
		
		// test of filterByName()
//		List<FoodItem> list = f.filterByName("ars");
//		for (int i = 0; i < list.size(); i++) {
//			System.out.println(list.get(i));
//		}
		
		
		
		
		// test of filterByNutrients()
//		List<String> a = new ArrayList<String>();
//		a.add("calories >= 300.0");
//		List<FoodItem> b = f.filterByNutrients(a);
//		System.out.println(b.size());
//		for (int i = 0; i < b.size(); i++) {
//			System.out.println(b.get(i));
//		}
		
		
		//test of addFoodItem()
//		FoodItem food = new FoodItem("3456789", "ImSoDumb");
//		f.addFoodItem(food);
//		
		//test of getAllFoodItems()
//		List<FoodItem> all = f.getAllFoodItems();
//		for (int i = 0; i < all.size(); i++) {
//			System.out.println(all.get(i).getID());
//		}
		
		//test of saveFoodItems()
//		f.saveFoodItems("foodItems.csv");
		
	}

}
