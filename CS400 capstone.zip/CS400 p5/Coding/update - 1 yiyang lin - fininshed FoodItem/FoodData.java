import java.io.*;
import java.util.*;

public class FoodData<F> implements FoodDataADT {

	private List<FoodItem> list;
	private BPTree<String, Double> t;
	FoodData() {

		list = new ArrayList<FoodItem>();
		t = new BPTree<String, Double>(3);
		
	}

	@Override
	public void loadFoodItems(String filePath) {
		String[][] details = new String[10000][7];
		Scanner input;
		try {
			input = new Scanner(new File(filePath));

			int i = 0;
			while (input.hasNext()) {
				String line = input.nextLine();
				String[] read = line.split(",");
				details[i][0] = read[0];
				details[i][1] = read[1];
				details[i][2] = read[3];
				details[i][3] = read[5];
				details[i][4] = read[7];
				details[i][5] = read[9];
				details[i][6] = read[11];

				FoodItem food = new FoodItem(read[0],read[1]);
				
				food.addNutrient(read[2],Double.parseDouble(read[3]));
				food.addNutrient(read[4],Double.parseDouble(read[5]));
				food.addNutrient(read[6],Double.parseDouble(read[7]));
				food.addNutrient(read[8],Double.parseDouble(read[9]));
				food.addNutrient(read[10],Double.parseDouble(read[11]));
				
				list.add(food);
				
//				for (int j = 0; j < 7; j++) {
//					System.out.print(details[i][j] + ", ");
//				}
//				System.out.println();
				
				i++;
			}
		} catch (Exception e) {
		}

	}

	@Override
	public List<F> filterByName(String substring) {
		
		
		
		return null;
	}

	@Override
	public List<F> filterByNutrients(List rules) {
		
		return null;
	}

	@Override
	public void addFoodItem(FoodItem foodItem) {

	}

	@Override
	public List<F> getAllFoodItems() {

		return null;
	}

	@Override
	public void saveFoodItems(String filename) {

	}

}
